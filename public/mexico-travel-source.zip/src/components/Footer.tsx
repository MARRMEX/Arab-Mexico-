import React from 'react';
import { NAV_ITEMS } from '../data/content';
import { MessageCircle, Phone, ArrowUp, Linkedin } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_PHONE_FORMATTED } from '../utils/whatsapp';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <footer id="main-footer" className="bg-stone-950 text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b border-stone-800/80">
          {/* Brand Info */}
          <div className="lg:col-span-6 flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <Logo size="md" variant="dark" />
              <div>
                <h3 className="text-xl font-bold tracking-tight">
                  <span className="text-amber-300">Arab Mexico </span>
                  <span className="text-emerald-400">Guide</span>
                </h3>
                <p className="text-xs text-emerald-300 font-semibold">
                  Your Arabic Travel Companion in Mexico
                </p>
                <p className="text-[11px] text-amber-400/90 font-medium">
                  Independent Travel Assistance &amp; Local Guidance
                </p>
              </div>
            </div>

            <p className="text-sm text-stone-400 max-w-md leading-relaxed mb-6 font-normal">
              Independent travel assistance, local recommendations, and Arabic-Spanish communication support designed specifically for Arabic-speaking travelers exploring Mexico.
            </p>

            {/* Direct WhatsApp Badge & LinkedIn */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-sm text-stone-300">
              <div className="flex items-center gap-2">
                <span className="text-stone-400">WhatsApp:</span>
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-mono font-medium transition-colors"
                  aria-label="WhatsApp Contact"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{WHATSAPP_PHONE_FORMATTED}</span>
                </a>
              </div>
              <a
                href="https://www.linkedin.com/company/tu-profe-mx/"
                target="_blank"
                rel="noopener noreferrer"
                id="footer-linkedin-button"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-900 hover:bg-stone-800 text-sky-400 hover:text-sky-300 border border-stone-800 hover:border-sky-500/40 text-xs font-medium transition-all"
                aria-label="Tu Profe MX on LinkedIn"
              >
                <Linkedin className="w-3.5 h-3.5 fill-current" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="lg:col-span-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-amber-400 mb-5">
              Quick Navigation
            </h4>
            <ul className="grid grid-cols-2 gap-3 text-sm">
              {NAV_ITEMS.map((item) => (
                <li key={item.name}>
                  <a
                    href={item.href}
                    onClick={(e) => handleNavClick(e, item.href)}
                    className="text-stone-300 hover:text-amber-300 transition-colors py-1 inline-block"
                  >
                    {item.name}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-medium transition-colors py-1 inline-flex items-center gap-1.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.linkedin.com/company/tu-profe-mx/"
                  target="_blank"
                  rel="noopener noreferrer"
                  id="footer-linkedin-nav"
                  className="text-sky-400 hover:text-sky-300 font-medium transition-colors py-1 inline-flex items-center gap-1.5"
                >
                  <Linkedin className="w-3.5 h-3.5 fill-current" />
                  <span>LinkedIn</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Quick Back to Top */}
          <div className="lg:col-span-2 flex flex-col justify-between items-start md:items-end">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-amber-400 mb-5">
                Back to Top
              </h4>
            </div>

            <div>
              <button
                type="button"
                onClick={scrollToTop}
                id="footer-back-to-top"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-stone-900 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-800 text-xs font-medium transition-all"
                aria-label="Back to top"
              >
                <span>Top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400">
          <p id="footer-copyright" className="text-center sm:text-left">
            Arab Mexico Guide &copy; 2026 &bull; Crafted with care for Arabic-speaking travelers.
          </p>

          <div className="flex items-center gap-1.5 text-stone-400">
            <span>Connecting cultures between the Arab World and Mexico</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
